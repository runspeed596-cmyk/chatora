rootProject.name = "SpringBoot"
